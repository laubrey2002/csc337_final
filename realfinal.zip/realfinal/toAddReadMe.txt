utils:
    -crypto
        -Add explanation for salting and reference for where in crpyto it came from
    -db
        -just the thing that creates the database for us

GENERAL:
    - Explain packaging and file paths
    - Add comment for style sheet tag used for CSS
    - Explanation for all html pages
    - Explanation for using "?" operand
    - Use of external tool to create image for edit button
    - Different res status codes for proper error handling of :400, 401, 403, 404
    - Add background information for app.delete used for deleting posts
    - Add background information for app.put used for posts
    - Go over form creations and submissions
    - async vs sync functions